-- MySQL dump 10.14  Distrib 5.5.50-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	5.5.50-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `blog`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `blog` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `blog`;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_84c5c92e_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_group_permissi_permission_id_84c5c92e_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permissi_content_type_id_2f476e4b_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add permission',4,'add_permission'),(11,'Can change permission',4,'change_permission'),(12,'Can delete permission',4,'delete_permission'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add ??',7,'add_post'),(20,'Can change ??',7,'change_post'),(21,'Can delete ??',7,'delete_post'),(22,'Can add ??',8,'add_tag'),(23,'Can change ??',8,'change_tag'),(24,'Can delete ??',8,'delete_tag');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$30000$u7OgXinTFLjH$R9rAqfg6xxsiNEZYmPbJCRYTDCfp8VcGcJZTIn62aAY=','2016-09-17 01:19:02',1,'admin','','','lidongzhang@rstone.com.cn',1,1,'2016-09-11 09:31:09');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_1fbb5f2c_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `auth_user_user_perm_permission_id_1fbb5f2c_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `body` longtext,
  `createDatetime` datetime NOT NULL,
  `updateDatetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_post`
--

LOCK TABLES `blog_post` WRITE;
/*!40000 ALTER TABLE `blog_post` DISABLE KEYS */;
INSERT INTO `blog_post` VALUES (1,'[整理] markdown 语法','换行   \r\n``行的末尾有两个空格``\r\n\r\n段落  \r\n`一个空行，是一个段落的分割`  \r\n\r\n标题  \r\n`# 这是 H1`  \r\n`## 这是 H2`  \r\n`###### 这是 H6`\r\n\r\n代码\r\n`` `标记，例如：`printf(\"hello world!\");` ``  \r\n代码段\r\n`开头用4个空格，并且前后各用一个空行隔开`  \r\n\r\n分割线  \r\n`***`\r\n\r\n链接  \r\n`[foo](http://example.com/) `\r\n\r\n整理\r\n`*single asterisks*`  \r\n`_single underscores_`  \r\n`**double asterisks**`  \r\n`__double underscores__`  \r\n\r\n图片  \r\n`![Alt text](/path/to/img.jpg \"Optional title\")`  \r\n\r\n列表  \r\n`*`  \r\n`-`  \r\n`+`','2016-09-11 11:18:27','2016-09-13 07:39:21'),(2,'[整理] linux常用命令','**tar**   \r\n tar -cvf   filename.tar  /etc  #打包  \r\ntar -xvf filename  \r\ntar -zcvf  filename.tar.gz /etc #gz压缩打包  \r\ntar -zxvf filename.tar.gz  \r\ntar -jcvf  filename.tar.bz2 #bz2压缩打包  \r\ntar -jxvf filename.tar.bz2  \r\n\r\n**scp**  \r\n scp   ./filename  username@adong.rstone.tech:~/   \r\n\r\n**ldd**  \r\n可以查看对库的引用和哪些需要的库没有  \r\nldd 程序名称/动态库名称\r\n\r\n**apachectl**  \r\n-M  查看所有加载的modules  \r\n\r\n**sudo配置**  \r\n以root身份运行visudo  \r\n在配置文件中增加：  \r\nusername  ALL=(ALL)    ALL\r\n\r\n**nice**  \r\nnice  [-n 數字] command  \r\n指定执行命令的运行优先级  \r\n选项与参数：  \r\n-n  ：后面接一个数值，數值的范围 -20 ~ 19。  \r\n举例：如果备份数据库建议运行优先级设置为19，这样优先级设置为最低不影响网站系统的运行。  \r\n\r\n**sed**    \r\nsed    \'s/要替换的内容/替换的内容/g\'   \r\n要提换的内容通过管道输入，在sed处理后再通过管道输出  \r\n\r\n**利用ssh执行远程服务器命令**   \r\nssh  servername  “cmd”  \r\n\r\n**dirname**  \r\n从给定的包含绝对路径的文件名中去除文件名（非目录的部分），然后返回剩下的路径（目录的部分）','2016-09-11 12:41:14','2016-09-15 02:47:33'),(3,'[整理]  django学习资料','**自强学堂：**  [django基础教程](http://www.ziqiangxuetang.com/django/django-tutorial.html)\r\n\r\n**mod_wsgi:** [modwsgi.readthedocs.io](https://modwsgi.readthedocs.io/)\r\n\r\n**django 官网** [django](https://www.djangoproject.com/)','2016-09-11 12:49:42','2016-09-15 08:48:43'),(4,'[整理]  mysql  character','**1.SET NAMES \'utf8\';**   \r\n它相当于下面的三句指令：   \r\nSET character_set_client = utf8;   \r\nSET character_set_results = utf8;   \r\nSET character_set_connection = utf8;  \r\n\r\n**2. 创建数据库**   \r\nmysql> create database name character set utf8; \r\n\r\n**3. 创建表**  \r\nCREATE TABLE `type` (   \r\n`id` int(10) unsigned NOT NULL auto_increment,   \r\n`flag_deleted` enum(\'Y\',\'N\') character set utf8 NOT NULL default \'N\',   \r\n`flag_type` int(5) NOT NULL default \'0\',   \r\n`type_name` varchar(50) character set utf8 NOT NULL default \'\',   \r\nPRIMARY KEY (`id`)   \r\n)  DEFAULT CHARSET=utf8;   \r\n\r\n**4. 修改数据库成utf8的.**  \r\nmysql> alter database name character set utf8; \r\n\r\n**5. 修改表默认用utf8.**  \r\nmysql> alter table tablename character set utf8; \r\n\r\n**6. 修改字段用utf8**  \r\nmysql> alter table tablename modify columnname varchar(50) CHARACTER SET utf8;','2016-09-11 13:14:20','2016-09-13 07:41:30'),(5,'[整理] H5相关资料','**bootstrp:**[bootcss](http://www.bootcss.com/)','2016-09-11 13:23:17','2016-09-13 07:42:15'),(6,'[整理]  ffmpeg资料--整理中','fmpeg:   \r\n  [雷霄骅](http://blog.csdn.net/column/details/ffmpeg-devel.html)    \r\n  [读取摄像头](http://blog.csdn.net/leixiaohua1020/article/details/39702113)    \r\n  [录屏](http://blog.csdn.net/leixiaohua1020/article/details/39706721)  \r\n  [ffmpeg 学习总结](http://blog.csdn.net/leixiaohua1020/article/details/15811977)\r\n\r\nffmpeg英文手册\r\n[地址](http://dranger.com/ffmpeg/tutorial03.html)\r\n\r\n摄像头捕获：[摄像头采集](http://blog.simophin.net/?p=825)  \r\n\r\n摄像头捕获：[摄像头采集照片](http://blog.csdn.net/smilefyx/article/details/33728881)\r\n\r\n远程监控h264: [远程监控h264](http://blog.chinaunix.net/uid-26851094-id-3276088.html)\r\n\r\nav_sample_get_buffer_size 大小计算: [地址](http://blog.csdn.net/oldmtn/article/details/48048687)\r\n\r\n[ 基于ffmpeg的简单音视频编解码的例子 ](http://blog.csdn.net/zqf_office/article/details/8676391)','2016-09-11 13:31:10','2016-09-13 07:46:30'),(7,'[介绍]  aspera 下载软件','一个采用自主协议，高下载速度的软件，国内目前用的还比较少，目前被IBM收购了。  \r\n官网地址：[asper](http://asperasoft.com/)  \r\n他的相关软件比较多（有服务器端、客户端、插件等等），初次使用的时候让人比较困惑。  \r\n只需到下载页面，下载client connect安装使用就可以了。  \r\n下载的方式是到专门的支持asper的网站，采用点击链接下载，目前国内还没有见到这样的下载网站。\r\n\r\n百度云盘下载地址： [百度云盘](http://pan.baidu.com/s/1cxaUIy)  \r\n密码：jsk2','2016-09-11 13:43:03','2016-09-17 01:26:20'),(8,'[整理] pythone相关资料','**python包索引网站：** [pypi.python.org](https://pypi.python.org/pypi)  \r\n\r\n**python 官网：**[python](https://www.python.org)','2016-09-11 13:47:12','2016-09-13 07:42:49'),(9,'[整理] v4l2 相关资料','[v4l2 sample](https://web.archive.org/web/20110707012738/http://alumnos.elo.utfsm.cl/~yanez/video-for-linux-2-sample-programs/)\r\n\r\n[v4l2 wiki](https://en.wikipedia.org/wiki/Video4Linux#Version_2)\r\n\r\n[v4l2 sample1](http://www.oschina.net/code/snippet_12_368)\r\n\r\n[v4l2 api 说明](https://linuxtv.org/downloads/v4l-dvb-apis/)\r\n\r\n[sample2](http://blog.chinaunix.net/uid-23065002-id-5176233.html)\r\n\r\n[基础介绍](http://www.cnblogs.com/emouse/archive/2013/03/04/2943243.html)\r\n\r\n[入门知识](http://blog.chinaunix.net/uid-26851094-id-3270803.html)','2016-09-11 14:54:22','2016-09-13 07:48:00'),(10,'[整理] linux视频采集处理介绍','[http://blog.sina.com.cn/s/blog_5b9734c50100tghr.html](http://blog.sina.com.cn/s/blog_5b9734c50100tghr.html)','2016-09-11 15:04:53','2016-09-13 07:43:12'),(11,'[整理] myql 备份与恢复','**冷备份：拷贝文件备份方法**    \r\n0.停止数据库  \r\nsystemctl stop mariadb  \r\n1. 授予用户reload权限    \r\ngrant reload on *.* to \'username\'@\'localhost\';  \r\n2.备份\r\n mysqlhotcopy -u blogRoot -p \"blogRoot,123\" blog /tmp/test   \r\n3.启动数据库  \r\nsystemctl start mariadb  \r\n注意：此方法可以保障备份数据的完整性，支持InnoDB数据库，但在还原的时候需要数据库的版本是一样的。  \r\n**还原数据库**  \r\n0、停止数据库 systemctl stop mariadb\r\n1、cp -rf  备份文件 mysql数据库文件位置  \r\n2、chown mysql:mysql数据库文件位置  \r\n3、启动数据库 systemctl start mariadb  \r\n\r\n注意：  \r\n最好同时备份 /etc/my.cnf 和 /etc/my.cnf.d 文件  \r\n获取数据库文件位置mysql> show variables like \'datadir\';  \r\n\r\n参考资料：    \r\n[http://www.jb51.net/article/22730.htm](http://www.jb51.net/article/22730.htm)','2016-09-12 13:23:15','2016-09-13 07:37:48'),(12,'[整理] mysql 用户及权限管理','**授予用户reload权限**  \r\ngrant reload on *.* to \'username\'@\'localhost\';','2016-09-12 13:54:25','2016-09-13 07:40:41'),(13,'[整理] mysql 确定数据库表是否为InnoDB类型','1.查看数据库版本：  \r\nmyql> select version();  \r\n2.mysql5.5 以上默认情况下使用的是InnoDB的引擎  \r\n3.查看表引擎类型  \r\nshow table status like \'auth_group\';  \r\n4.InnerDB 引擎的数据库支持事务','2016-09-12 14:37:26','2016-09-13 07:39:55'),(14,'[原创] git 操作笔记','1.配置git服务器  \r\n\r\n    sudo apt-get install git  \r\n    adduser git  \r\n    \r\n收集所有需要登录的用户的公钥，就是他们自己的id_rsa.pub文件，把所有公钥导入到/home/git/.ssh/authorized_keys文件里，一行一个。  \r\n    先选定一个目录作为Git仓库，假定是/srv/sample.git，在/srv目录下输入命令：  \r\n\r\n    git init --bare sample.git  \r\n    chown -R git:git sample.git  \r\n    \r\n出于安全考虑，第二步创建的git用户不允许登录shell，这可以通过编辑/etc/passwd文件完成。找到类似下面的一行：  \r\n\r\n    git:x:1001:1001:,,,:/home/git:/bin/bash  \r\n    改为：  \r\n    git:x:1001:1001:,,,:/home/git:/usr/bin/git-shell  \r\n  \r\n2.添加后，远程库的名字就是origin  \r\n    在本地注册版本库  \r\n\r\n    git remote add origin git@github.com:michaelliao/learngit.git  \r\n    git push -u origin master   \r\n\r\n由于远程库是空的，我们第一次推送master分支时，加上了-u参数，Git不但会把本地的master分支内容推送的远程新的master分支，还会把本地的master分支和远程的master分支关联起来，在以后的推送或者拉取时就可以简化命令。  \r\n\r\n    git push origin master  \r\n  \r\n3.分支  \r\n    创建本地分支  \r\n\r\n    git branch   branch1 #当前分支内容会带到创建分支中  \r\n    git checkout branch1 #切换到本地分支  \r\n    git push --set-upstream origin dev   #设置本地分支和远程分支关系  \r\n    git push  #推送文件  \r\n  \r\n或者显示的从远程创建分支  \r\n\r\n    git checkout -b branch1 origin/branch1  \r\n  \r\n    git pull #会和远程分支的内容进行合并  \r\n    git push #会把本地分支内容 推送到远程 同名版本库  \r\n    git remote -v #查看注册版本库  \r\n    git branch -r #查看远程分支  \r\n  \r\n   git config --global push.default simple   #设置只推送当前分支 从2.0开始  \r\n  \r\n4.开发分支  \r\n  主分支master 只有在功能发布的时候才提交到主分支  \r\n  dev  开发人员把自己开发测试后的结果提交到此分支，项目负责人在这个分支检查  \r\n  devOne 开发人员自己的开发分支，只可以提交到dev分支，不能提交到master分支。  \r\n  \r\n  在分支切换的时候一定要把工作区和stage清理干净。   \r\n  首选 git commit  \r\n  次选 git stash  保存工作区和stage  \r\n  \r\n5.注意事项  \r\n    工作区和暂存区是不和分支联系的，所以在切换分支前一定要处理好工作区和  \r\n    暂存区的数据  \r\n\r\n    git stash       #存储工作区  \r\n    git stash list    \r\n    git stash apply  #恢复工作区域 存储不删除  \r\n    git stash pop    #恢复工作区   并删除存储  \r\n    git stash apply stash@{0}  #回复多次的存储  \r\n  \r\n  推送后提示不是快速推送，需要先pull 再做 push ，不要使用 -f 避免数据相互覆盖  \r\n  也就是要在每次push前先pull  \r\n    \r\n    git pull  \r\n    git push  \r\n  \r\n  合并不要使用fastfoward 模式，这样可以保持合并的路径  \r\n\r\n    git merge --no-ff develop  \r\n  \r\n6.常用命令  \r\n  本版本和上一版本比较变化的文件列表  \r\n\r\n    git diff --name-status HEAD HEAD^  \r\n  \r\n  查看图形化的git log  \r\n\r\n    git log --graph --pretty=oneline  \r\n  \r\n    git add .  #添加本目录下的所有文件和目录  \r\n   \r\n  生成公钥\r\n    \r\n    ssh-keygen -t rsa -C \"youremail@example.com\"  \r\n  \r\n  没有远程分支 通过push 直接创建分支  \r\n\r\n    git push --set-upstream origin dev  \r\n  \r\n  pull的时候没有分支，指定分支  \r\n\r\n    git pull origin devone  \r\n  \r\n 列出远程分支  \r\n\r\n    git branch -r  \r\n  \r\n  根据远程分支创建一个本地分支  \r\n\r\n    git branch adong origin/adong  \r\n  \r\n  合并devone分支到当前分支  \r\n\r\n    git merge devone  \r\n  \r\n  删除分支  \r\n\r\n    git branch -d devone  \r\n  \r\n  git 图形界面  \r\n\r\n    apt-get install git-gui  \r\n    git gui #图形界面  \r\n    gitk    #历史图形界面  \r\n      \r\n  \r\n  现实里程碑列表  \r\n\r\n    git tag  \r\n    git tag -n1  #显示一行里程碑说明  \r\n    git tag -l  v*  #l参数 支持通配符  \r\n    git log --oneline --decorate  #显示对应的里程碑信息  \r\n    git tag -m \"说明\" tagname  #在创建提交后马上打上一个tag  \r\n    git tag -d tagname  #删除tag  \r\n    git push origin refs/tags/*  #推送tag到远程服务器  \r\n    git push origin :tagname  #删除远程服务器上的tag  \r\n\r\n  命名规则：例如： v1.0.0     #正式发布版本  \r\n		     v1.0.0.1   #最后一个1是对版本修改的版本号  \r\n                     v1.0.0-rc1 #rc 预发布版本      \r\n    \r\n    把当前分支已经提交的内容和master分支比较，不同的内容生成patch文件，可能不止一个文件(每次提交生成一个文件)。  \r\n\r\n    git format-patch -M master  \r\n    \r\n  应用patch  \r\n  一般都是先开一个测试patch的分支，测试ok后再合并到master上  \r\n\r\n    git am patch文件名   \r\n  \r\n------------------------------------------------------------------------  \r\n配置邮件查看、收发  \r\n  \r\n  mutt 邮件客户端 只能看邮件 编辑邮件 收发需要其他工具帮助  \r\n  msmtp  发送邮件程序  \r\n  getmail 收邮件程序  \r\n  \r\n  -----msmtp 配置--------------------------------------  \r\n  \r\n  msmtp(邮件客户端，用于发送邮件,使用网上的邮箱服务器):  \r\n\r\n    apt-get install msmtp  \r\n    msmtp --version  \r\n\r\n    配置：  \r\n\r\n	vim /etc/msmtprc  \r\n		# Set default values for all following accounts.  \r\n		defaults  \r\n		logfile /home/adong/.msmtp.log  \r\n		# The SMTP server of the provider.  \r\n		account adong  \r\n		host smtp.163.com  \r\n		from lidongzhang163@163.com  \r\n		auth login  \r\n		user lidongzhang163@163.com  \r\n		password 274000  \r\n		# Set a default account  \r\n		account default : adong  \r\n  \r\n  创建空文件 .msmtp.log  \r\n   \r\n  ----mutt 配置  ---------------------------------------------------------  \r\n\r\n	vim .muttrc (注意与msmtp 和 getmail 配置的对应关系)   \r\n		#发邮件  \r\n		set sendmail=\"/usr/bin/msmtp\"  \r\n		set use_from=yes  \r\n		set realname=\"lidongzhang\"  \r\n		set from=lidongzhang163@163.com  \r\n		set envelope_from=yes  \r\n  \r\n		#收邮件  \r\n		set mbox_type=Maildir  \r\n		set folder=$HOME/.mail  \r\n		set spoolfile=~/.mail/inbox  \r\n		#set header_cache=~/.mail/.hcache  \r\n  \r\n  ---getmail--------------------------------------------------  \r\n\r\n	apt-get install getmail4  \r\n	mkdir ~/.getmail  \r\n	cd ~/.getmail  \r\n	vim getmailrc  \r\n		[options]  \r\n		#verbose = 0  \r\n		delete = false  \r\n		message_log = ~/log/getmail.log  \r\n  \r\n		[retriever]  \r\n		type = SimplePOP3SSLRetriever  \r\n		server = pop.163.com  \r\n		username = lidongzhang163@163.com  \r\n		port = 995  \r\n		password = 274000  \r\n		  \r\n		[destination]  \r\n		type = Maildir  \r\n		path = ~/.mail/inbox/  \r\n  \r\n  测试：  \r\n\r\n	/usr/bin/getmail -n  #参数 -n 只收取新邮件  \r\n	  \r\n  \r\n  ----mutt命令行发送邮件-------------------------------------------------  \r\n  \r\n  测试：  \r\n\r\n		echo \"test中文\" | mutt -s \"my first test中文\" lidongzhang163@163.com   \r\n  \r\n		mutt -s \"标题\"  lidongzhang163@163.com -a 附件文件名称 <文本文件  \r\n  \r\n  ---综合使用说明------------------------------------------------  \r\n        mutt tui界面操作，查看，写邮件，调用msmtp发邮件  \r\n	mutt 命令行发邮件 可以含附件  \r\n	msmtp 配置好就可以不需要直接使用都是透过 mutt调用的  \r\n	getmail  执行一次收一次邮件，mutt查看邮件前要用此收一次邮件  \r\n		 可以做成自动执行的任务，避免手动执行遗漏邮件  \r\n  \r\n  \r\n  ------------------------------------------------------		  \r\n   \r\n  使用git发送patch邮件，首先安装(需要安装邮件客户端，msmtp)  \r\n\r\n    apt-get install git-email  \r\n    #git send-email *.patch  \r\n    git config --global sendemail.smtpserver /usr/bin/msmtp  \r\n　　git config --global sendemail.chainreplyto false  \r\n    #发送所有patch，每个patch会产生一个邮件  \r\n    git send-email --to=lidongzhang163@163.com --to=xx  --cc=xxx   --compose *.patch  \r\n  \r\n    #应用patch  \r\n    使用mutt 把需要应用的patch邮件保存下来  \r\n    在工作区使用如下命令应用：  \r\n    git am 保存的邮件文件名  \r\n  \r\n7.排除的文件  \r\n    暂时感觉不需要   \r\n  \r\n-------------------------------------------------------------------------------  \r\ngitolite  \r\n  \r\n安装及说明文件见：  \r\nhttps://github.com/sitaramc/gitolite#readme  \r\n注意： git权威指南中的版本太老了，不能全部参考。  \r\n配置 公钥的时候 对 /home/user 目录 和 /home/user/.ssh 目录的权限是要求极高的  \r\n     对验证文件的要求也很高，权限配置错误 则 验证无法通过。  \r\n  \r\n  \r\n配置文件： （如何配置 branch 的权限）  \r\n在配置文件中增加 新的 repo 的配置 git push 后会自动建立 相应的库  \r\n可以设置对库的权限  \r\n也可以设置对库中不同分支的权限  \r\n  \r\nMy config, that is working now:  \r\n  \r\n    @gatekeepers = ustimenko  \r\n    @developers  = ustimenko user1 user2  \r\n    @deployers   = puppet  \r\n  \r\n    @project     = repo1  \r\n    @project     = cakephp  \r\n  \r\n    repo @project  \r\n    RW+                 = @gatekeepers    \r\n    R   master develop  = @developers  \r\n    -   master develop  = @developers  \r\n    RW+                 = @developers  \r\n    R                   = @deployers  \r\n  \r\n    Gatekeepers have full access.  \r\n    Developers can read master and develop branches, then they denied other actions there.  \r\n    Developers can do all other things.  \r\n    Deployers can read all.  \r\n  \r\n问题：  \r\n	1. 如何从一个分支的历史提交创建新分支  \r\n  	2. 如何合并一个分到本分支  \r\n		A.原分支不动  \r\n  		B.删除原分支  \r\n  ------------------------------------------------------------------------------  \r\n开发分支模型参考： （前后页面有不同的模型）  \r\nhttp://blog.jobbole.com/76867/  \r\n  \r\n项目开发管理：  \r\n1.配置文件配置好repo 后会自动建立相应的 git库。  \r\n2.建立如下分支：  \r\n  \r\n    repo demo  \r\n      分支          权限          人员       说明  \r\n	master        RW+           adong      主分支,稳定发布分支，需要打标签  \r\n                      R             devone       \r\n	dev           RW+           adong      开发汇总，代码审核  \r\n                      R             devone  \r\n	release       RW+           adong      发布分支，发布前测试，需要阶段打标签  \r\n		      R             devone       \r\n	adong_dev     RW+           adong      adong开发分支  \r\n                      R             devone  \r\n	devone_dev    RW+           adong      devone开发分支  \r\n                      RW+           devone  \r\n  \r\n3.初始化步骤  \r\n  A.安装 git gitolite  \r\n  B.本地创建git repo，把初始内容push到远程服务器master 打标签 v0.0.0  \r\n  C.在master版本基础上创建 dev 分支，并push到 origin 打标签 v0.0.0  \r\n4.使用说明  \r\n  A.bug修复  \r\n     以devone人员为例：具体工作步骤如下  \r\n        0.当有bug需要修复的时候：  \r\n	1.如果没有devone_fix分支创建此分支  \r\n	2.清空工作区域和stage 做一次  \r\n	3.pull master上需要修复版本的内容。','2016-09-13 06:25:04','2016-09-13 06:57:23'),(15,'[整理] linxu常用技巧','**在脚本中如何自动输入密码**  \r\necho 密码 | sudo ls\r\n\r\n**在脚本中获取脚本文件所在目录**  \r\n\r\n    #!/bin/bash\r\n    DIR=\"$( cd \"$( dirname \"$0\"  )\" && pwd  )\"  \r\n\r\n缺陷是对于软链接显示的是软链接所在的目录','2016-09-13 09:30:08','2016-09-15 02:35:31'),(16,'[原创] 网站自动备份并保存到github','**需求：**  \r\n1、对网站和mysql数据库进行备份  \r\n2、把备份的内容保存到github  \r\n3、整个过程通过脚本自动完成  \r\n**准备条件**  \r\n1、有github账户  \r\n2、配置好github的用户证书，无需输入用户名和密码就可以和github交互。\r\n\r\n    ssh -T git@github.com  #进行测试验证\r\n\r\n3、本地git设置采用ssh形式和github交互。  \r\n\r\n    git remote set-url origin  git@github.com:USERNAME/OTHERREPOSITORY.git\r\n\r\n**脚本**  \r\n\r\n    database=blog\r\n    mysqlusername=mysqlusername\r\n    mysqlpassword=mysqlpassword\r\n\r\n    #生成备份sql语句\r\n    echo $mysqlpassword |  nice -n 19 mysqldump -u$mysqlusername -p$mysqlpassword  --database    $database  > $database-$(date +%Y%m%d).sql\r\n\r\n    # 将生成的SQL文件压缩\r\n    nice -n 19 tar zPcf $database-$(date +%Y%m%d).sql.tar.gz $database-$(date +%Y%m%d).sql\r\n\r\n    # 删除7天之前的备份数据\r\n    find . -mtime +7 -name \"*.sql.tar.gz\" -exec rm -rf {} \\;\r\n\r\n    # 删除生成的SQL文件\r\n    rm -rf ./*.sql\r\n\r\n    git add .\r\n    git commit -m \"$(date +%Y%m%d)\"\r\n    git push','2016-09-14 05:15:22','2016-09-14 05:24:48'),(17,'[原创]  django 网站自动发布(适用于所有项目)','**需求**  \r\n1、开发机：修改后的网站发布到github上  \r\n2、服务器：  \r\n    A、git stash 把修改的内容进行存储 （修改后的内容是不要保留的）  \r\n    B、从github上git pull   下修改内容  \r\n    C、修改app\\setting.py 中的数据库及其他参数  \r\n    D、更新数据库结构\r\n3、更新脚本在开发机器上一次执行完成  \r\n**基础条件**  \r\n1、客户机和服务器需要和github 做好登录验证证书  \r\n2、客户端和服务器要做好登录验证证书  \r\n**脚本**  \r\n需要编写两个脚本pub.sh(在客户端的主执行文件) 和 dopull.sh   \r\n\r\npub.sh\r\n\r\n    #!/bin/bash\r\n                                   \r\n    cd $(dirname $0)\r\n\r\n    if [ ! $# == 3 ]; then\r\n      echo \"用法: $0 服务器数据库用户名 密码 发送邮件邮箱密码\"\r\n      exit\r\n    fi\r\n\r\n    mysqlusername=$1\r\n    mysqluserpassword=$2\r\n    sendemailpassword=$3\r\n\r\n    git add .\r\n    git commit -m \"$(date +%Y%m%d)\"\r\n    git push\r\n\r\n    ssh t.rstone.com.cn ~/website/dopull.sh $mysqlusername $mysqluserpassword $sendemailpassword\r\n\r\ndopull.sh  \r\n\r\n    #!/bin/bash                                                                            \r\n    cd $(dirname $0)\r\n\r\n    mysqlusername=$1\r\n    mysqluserpassword=$2\r\n    sendemailpassword=$3\r\n\r\n    git add .\r\n    git stash\r\n    git pull\r\n\r\n    mv  app/settings.py   app/settings.py.1\r\n    cat app/settings.py.1 | sed \"s/\'USER\': \'sa\',/\'USER\': \'$mysqlusername\',/g\" > app/settings.py\r\n\r\n    mv  app/settings.py   app/settings.py.1\r\n    cat app/settings.py.1 | sed \"s/\'PASSWORD\': \'sa\',/\'PASSWORD\': \'$mysqluserpassword\',/g\"   app/settings.py\r\n\r\n    mv  app/settings.py   app/settings.py.1\r\n    cat app/settings.py.1 | sed \"s/EMAIL_HOST_PASSWORD = \'\'/EMAIL_HOST_PASSWORD = \'$sendem    ailpassword\'/g\" > app/settings.py\r\n\r\n    rm app/settings.py.1\r\n\r\n    python3 manage.py makemigrations\r\n    python3 manage.py migrate\r\n\r\n**执行**  \r\n在开发机上执行： pub.sh 服务器mysql数据库用户名 服务器mysql数据库用户密码 发送邮件邮箱密码','2016-09-14 10:36:49','2016-09-17 01:02:51'),(18,'[整理]  linux 用户通过证书免密码登录','**客户端**  \r\n\r\n    ssh-keygen -t rsa -C \"youremail@example.com\"  \r\n\r\n上面命令中的youremail@example.com比较重要，如果使用此证书和github进行交互认证，就要把它设置为github的用户名。  \r\n执行此命令后会在~/.ssh/目录下生成 id_rsa  id_rsa.pub 两个文件\r\n\r\n**服务器端**  \r\nvim /etc/ssh/sshd_config\r\n\r\n    #禁用root账户登录，非必要，但为了安全性，请配置\r\n    PermitRootLogin no\r\n\r\n    # 是否允许用户自行使用成对的密钥系统进行登入行为，仅针对 version 2。\r\n    # 至于自制的公钥数据就放置于用户家目录下的 .ssh/authorized_keys 内\r\n    RSAAuthentication yes\r\n    PubkeyAuthentication yes\r\n    AuthorizedKeysFile      %h/.ssh/authorized_keys\r\n\r\n把客户端生成的 id_rsa.pub 导入服务器\r\ncat  id_rsa.pub >> ～/.ssh/authorized_keys','2016-09-15 01:57:36','2016-09-15 01:58:28'),(19,'[整理] emacs 常用功能整理','进入shell，使用eshell 不使用 M_x shell 界面操作要好用些。  \r\nM_x  eshell  \r\n\r\n C-x u 向后撤销  \r\n\r\n\r\n取消自动备份文件  \r\n在 ~/ 目录下的 .emacs 文件里加入下面一行：  \r\n(setq backup-directory-alist (quote ((\".\" . \"~/.backups\"))))','2016-09-15 05:13:33','2016-09-15 11:12:59'),(20,'[整理] django常见问题','更新使用apache+wsgi发布的网站，如果出现url访问不正常的，需要重启apache服务。  \r\n\r\n多对多的访问：  \r\n\r\n    t = Tag.objects.get(id=1)  #此处必须是一个记录\r\n    p = t.post_set.all()','2016-09-15 08:52:28','2016-09-15 09:20:58'),(21,'[整理]  linux脚本相关知识','**判断参数个数**  \r\n\r\n    if [ ! $# == 2 ]; then    #其中$#代表的是参数的个数不包含文件名本身\r\n      echo \"Usage: $0 weight_in_kilos length_in_centimeters\"\r\n      exit\r\n    fi','2016-09-16 12:27:02','2016-09-16 12:37:19'),(22,'[整理] python3 常用功能','**md5加密**  \r\n\r\n    import hashlib\r\n    hash = hashlib.sha1()\r\n    hash.update(\'admin\'.encode(\'utf-8\'))\r\n    print(hash.hexdigest())','2016-09-17 12:21:07','2016-09-17 12:21:07');
/*!40000 ALTER TABLE `blog_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_post_tag`
--

DROP TABLE IF EXISTS `blog_post_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_post_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_post_tag_post_id_ba2a5f83_uniq` (`post_id`,`tag_id`),
  KEY `blog_post_tag_tag_id_2bbd31e4_fk_blog_tag_id` (`tag_id`),
  CONSTRAINT `blog_post_tag_post_id_a5c00319_fk_blog_post_id` FOREIGN KEY (`post_id`) REFERENCES `blog_post` (`id`),
  CONSTRAINT `blog_post_tag_tag_id_2bbd31e4_fk_blog_tag_id` FOREIGN KEY (`tag_id`) REFERENCES `blog_tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_post_tag`
--

LOCK TABLES `blog_post_tag` WRITE;
/*!40000 ALTER TABLE `blog_post_tag` DISABLE KEYS */;
INSERT INTO `blog_post_tag` VALUES (1,1,1),(2,2,5),(3,3,2),(4,4,7),(5,5,8),(6,6,4),(7,7,6),(8,8,3),(9,9,5),(10,10,5),(11,11,7),(12,12,7),(13,13,7),(14,14,9),(15,15,5),(16,16,10),(17,17,2),(18,18,5),(19,19,11),(20,20,2),(21,21,5),(22,22,3);
/*!40000 ALTER TABLE `blog_post_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tag`
--

LOCK TABLES `blog_tag` WRITE;
/*!40000 ALTER TABLE `blog_tag` DISABLE KEYS */;
INSERT INTO `blog_tag` VALUES (1,'markdown'),(2,'django'),(3,'python3'),(4,'ffmpeg'),(5,'linux'),(6,'other'),(7,'mysql'),(8,'h5'),(9,'git'),(10,'运维'),(11,'emacs');
/*!40000 ALTER TABLE `blog_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) DEFAULT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_c4bce8eb_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin__content_type_id_c4bce8eb_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2016-09-11 11:16:55','1','markdown',1,'[{\"added\": {}}]',8,1),(2,'2016-09-11 11:18:27','1','markdown ??',1,'[{\"added\": {}}]',7,1),(3,'2016-09-11 11:24:01','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(4,'2016-09-11 11:25:41','1','markdown',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(5,'2016-09-11 11:25:51','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(6,'2016-09-11 11:27:03','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(7,'2016-09-11 11:29:18','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(8,'2016-09-11 11:29:59','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(9,'2016-09-11 11:30:43','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(10,'2016-09-11 11:31:19','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(11,'2016-09-11 11:31:49','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(12,'2016-09-11 11:33:36','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(13,'2016-09-11 11:34:02','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(14,'2016-09-11 11:34:27','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(15,'2016-09-11 11:35:10','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(16,'2016-09-11 11:36:30','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(17,'2016-09-11 11:37:22','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(18,'2016-09-11 11:37:48','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(19,'2016-09-11 11:41:06','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(20,'2016-09-11 11:45:29','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(21,'2016-09-11 11:47:29','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(22,'2016-09-11 11:48:10','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(23,'2016-09-11 11:49:51','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(24,'2016-09-11 11:50:16','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(25,'2016-09-11 11:51:03','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(26,'2016-09-11 11:51:44','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(27,'2016-09-11 11:52:46','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(28,'2016-09-11 11:53:10','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(29,'2016-09-11 11:53:37','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(30,'2016-09-11 11:54:37','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(31,'2016-09-11 11:55:54','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(32,'2016-09-11 11:56:41','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(33,'2016-09-11 11:58:01','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(34,'2016-09-11 11:59:49','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(35,'2016-09-11 12:01:42','1','markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(36,'2016-09-11 12:02:09','1','[??] markdown ??',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(37,'2016-09-11 12:35:07','1','[??] markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(38,'2016-09-11 12:36:05','2','django',1,'[{\"added\": {}}]',8,1),(39,'2016-09-11 12:36:29','3','python3',1,'[{\"added\": {}}]',8,1),(40,'2016-09-11 12:36:47','4','ffmpeg',1,'[{\"added\": {}}]',8,1),(41,'2016-09-11 12:36:56','5','linux',1,'[{\"added\": {}}]',8,1),(42,'2016-09-11 12:37:06','6','other',1,'[{\"added\": {}}]',8,1),(43,'2016-09-11 12:41:14','2','[??] linux????',1,'[{\"added\": {}}]',7,1),(44,'2016-09-11 12:42:19','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(45,'2016-09-11 12:42:38','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(46,'2016-09-11 12:46:15','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(47,'2016-09-11 12:46:45','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(48,'2016-09-11 12:49:42','3','[??]  django????',1,'[{\"added\": {}}]',7,1),(49,'2016-09-11 12:50:11','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(50,'2016-09-11 12:51:04','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(51,'2016-09-11 12:52:25','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(52,'2016-09-11 12:53:57','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(53,'2016-09-11 12:55:39','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(54,'2016-09-11 12:56:08','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(55,'2016-09-11 12:56:50','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(56,'2016-09-11 12:57:13','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(57,'2016-09-11 12:58:09','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(58,'2016-09-11 12:59:12','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(59,'2016-09-11 13:00:35','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(60,'2016-09-11 13:01:11','1','[??] markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(61,'2016-09-11 13:01:27','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(62,'2016-09-11 13:02:22','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(63,'2016-09-11 13:03:03','1','[??] markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(64,'2016-09-11 13:03:31','1','[??] markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(65,'2016-09-11 13:03:51','1','[??] markdown ??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(66,'2016-09-11 13:05:01','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(67,'2016-09-11 13:07:20','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(68,'2016-09-11 13:10:07','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(69,'2016-09-11 13:10:34','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(70,'2016-09-11 13:12:29','7','mysql',1,'[{\"added\": {}}]',8,1),(71,'2016-09-11 13:14:20','4','[??]  mysql??',1,'[{\"added\": {}}]',7,1),(72,'2016-09-11 13:17:31','4','[??]  mysql??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(73,'2016-09-11 13:18:03','4','[??]  mysql??',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(74,'2016-09-11 13:22:57','8','h5',1,'[{\"added\": {}}]',8,1),(75,'2016-09-11 13:23:17','5','[??] H5????',1,'[{\"added\": {}}]',7,1),(76,'2016-09-11 13:31:10','6','[??]  ffmpeg??--???',1,'[{\"added\": {}}]',7,1),(77,'2016-09-11 13:33:42','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(78,'2016-09-11 13:43:03','7','[??]  aspera ????',1,'[{\"added\": {}}]',7,1),(79,'2016-09-11 13:43:56','7','[??]  aspera ????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(80,'2016-09-11 13:44:55','7','[??]  aspera ????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(81,'2016-09-11 13:45:17','7','[??]  aspera ????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(82,'2016-09-11 13:47:12','8','[??] pythone????',1,'[{\"added\": {}}]',7,1),(83,'2016-09-11 13:47:33','8','[??] pythone????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(84,'2016-09-11 13:51:39','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(85,'2016-09-11 13:53:13','8','[??] pythone????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(86,'2016-09-11 13:57:18','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(87,'2016-09-11 13:57:47','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(88,'2016-09-11 13:58:16','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(89,'2016-09-11 13:58:34','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(90,'2016-09-11 14:00:44','3','[??]  django????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(91,'2016-09-11 14:02:52','2','[??] linux????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(92,'2016-09-11 14:29:50','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(93,'2016-09-11 14:30:02','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(94,'2016-09-11 14:34:49','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(95,'2016-09-11 14:39:16','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(96,'2016-09-11 14:40:53','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(97,'2016-09-11 14:42:09','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(98,'2016-09-11 14:44:24','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(99,'2016-09-11 14:44:45','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(100,'2016-09-11 14:45:53','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(101,'2016-09-11 14:51:39','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(102,'2016-09-11 14:53:55','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(103,'2016-09-11 14:54:22','9','[??] v4l2 ????',1,'[{\"added\": {}}]',7,1),(104,'2016-09-11 15:00:28','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(105,'2016-09-11 15:01:00','9','[??] v4l2 ????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(106,'2016-09-11 15:04:53','10','[??] linux????????',1,'[{\"added\": {}}]',7,1),(107,'2016-09-11 15:06:00','9','[??] v4l2 ????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(108,'2016-09-11 15:06:44','9','[??] v4l2 ????',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(109,'2016-09-11 15:08:02','6','[??]  ffmpeg??--???',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(110,'2016-09-12 13:10:07','4','[??]  mysql  character',2,'[{\"changed\": {\"fields\": [\"title\", \"body\"]}}]',7,1),(111,'2016-09-12 13:10:35','6','[??]  ffmpeg??--???',2,'[]',7,1),(112,'2016-09-12 13:13:03','4','[??]  mysql  character',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(113,'2016-09-12 13:14:29','4','[整理]  mysql  character',2,'[]',7,1),(114,'2016-09-12 13:23:15','11','[备份]备份相关',1,'[{\"added\": {}}]',7,1),(115,'2016-09-12 13:27:39','2','[整理] linux常用命令',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(116,'2016-09-12 13:54:25','12','用户及权限管理',1,'[{\"added\": {}}]',7,1),(117,'2016-09-12 13:54:51','12','[整理] mysql 用户及权限管理',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(118,'2016-09-12 13:58:00','11','[备份] myql 备份',2,'[{\"changed\": {\"fields\": [\"title\", \"body\"]}}]',7,1),(119,'2016-09-12 13:58:33','11','[备份] myql 备份',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(120,'2016-09-12 14:14:37','11','[备份] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"title\", \"body\"]}}]',7,1),(121,'2016-09-12 14:15:07','11','[备份] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(122,'2016-09-12 14:16:25','11','[备份] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(123,'2016-09-12 14:16:43','11','[整理] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"title\"]}}]',7,1),(124,'2016-09-12 14:25:31','11','[整理] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(125,'2016-09-12 14:34:16','11','[整理] myql 备份与恢复',2,'[]',7,1),(126,'2016-09-12 14:37:26','13','[整理] mysql 确定数据库表是否为InnoDB类型',1,'[{\"added\": {}}]',7,1),(127,'2016-09-12 14:38:01','13','[整理] mysql 确定数据库表是否为InnoDB类型',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(128,'2016-09-12 14:39:34','13','[整理] mysql 确定数据库表是否为InnoDB类型',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(129,'2016-09-12 14:40:45','13','[整理] mysql 确定数据库表是否为InnoDB类型',2,'[]',7,1),(130,'2016-09-12 14:43:01','11','[整理] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(131,'2016-09-13 06:13:46','11','[整理] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(132,'2016-09-13 06:22:49','9','git',1,'[{\"added\": {}}]',8,1),(133,'2016-09-13 06:25:04','14','[原创] git 操作笔记',1,'[{\"added\": {}}]',7,1),(134,'2016-09-13 06:28:57','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(135,'2016-09-13 06:29:37','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(136,'2016-09-13 06:30:53','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(137,'2016-09-13 06:31:18','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(138,'2016-09-13 06:31:44','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(139,'2016-09-13 06:33:07','1','[整理] markdown 语法',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(140,'2016-09-13 06:33:40','1','[整理] markdown 语法',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(141,'2016-09-13 06:34:16','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(142,'2016-09-13 06:35:38','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(143,'2016-09-13 06:36:25','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(144,'2016-09-13 06:37:49','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(145,'2016-09-13 06:38:18','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(146,'2016-09-13 06:40:00','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(147,'2016-09-13 06:40:25','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(148,'2016-09-13 06:40:51','1','[整理] markdown 语法',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(149,'2016-09-13 06:41:53','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(150,'2016-09-13 06:43:41','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(151,'2016-09-13 06:45:18','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(152,'2016-09-13 06:52:06','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(153,'2016-09-13 06:56:32','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(154,'2016-09-13 06:57:23','14','[原创] git 操作笔记',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(155,'2016-09-13 07:37:48','11','[整理] myql 备份与恢复',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(156,'2016-09-13 07:39:21','1','[整理] markdown 语法',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(157,'2016-09-13 07:39:55','13','[整理] mysql 确定数据库表是否为InnoDB类型',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(158,'2016-09-13 07:40:29','2','[整理] linux常用命令',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(159,'2016-09-13 07:40:41','12','[整理] mysql 用户及权限管理',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(160,'2016-09-13 07:41:30','4','[整理]  mysql  character',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(161,'2016-09-13 07:42:15','5','[整理] H5相关资料',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(162,'2016-09-13 07:42:38','7','[介绍]  aspera 下载软件',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(163,'2016-09-13 07:42:49','8','[整理] pythone相关资料',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(164,'2016-09-13 07:43:02','3','[整理]  django学习资料',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(165,'2016-09-13 07:43:12','10','[整理] linux视频采集处理介绍',2,'[]',7,1),(166,'2016-09-13 07:43:54','6','[整理]  ffmpeg资料--整理中',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(167,'2016-09-13 07:44:55','6','[整理]  ffmpeg资料--整理中',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(168,'2016-09-13 07:45:58','6','[整理]  ffmpeg资料--整理中',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(169,'2016-09-13 07:46:30','6','[整理]  ffmpeg资料--整理中',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(170,'2016-09-13 07:48:00','9','[整理] v4l2 相关资料',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(171,'2016-09-13 08:09:32','2','[整理] linux常用命令',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(172,'2016-09-13 09:30:08','15','[整理] linxu常用技巧',1,'[{\"added\": {}}]',7,1),(173,'2016-09-14 05:08:06','10','运维',1,'[{\"added\": {}}]',8,1),(174,'2016-09-14 05:15:22','16','[原创] 网站自动备份并保存到github',1,'[{\"added\": {}}]',7,1),(175,'2016-09-14 05:15:45','16','[原创] 网站自动备份并保存到github',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(176,'2016-09-14 05:22:51','16','[原创] 网站自动备份并保存到github',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(177,'2016-09-14 05:23:41','16','[原创] 网站自动备份并保存到github',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(178,'2016-09-14 05:24:48','16','[原创] 网站自动备份并保存到github',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(179,'2016-09-14 09:44:49','2','[整理] linux常用命令',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(180,'2016-09-14 10:36:49','17','[原创]  django网站自动发布',1,'[{\"added\": {}}]',7,1),(181,'2016-09-14 10:43:27','17','[原创]  django网站自动发布',2,'[]',7,1),(182,'2016-09-14 10:44:31','2','[整理] linux常用命令',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(183,'2016-09-15 01:57:36','18','[整理]  linux 用户通过证书免密码登录',1,'[{\"added\": {}}]',7,1),(184,'2016-09-15 01:58:28','18','[整理]  linux 用户通过证书免密码登录',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(185,'2016-09-15 02:35:31','15','[整理] linxu常用技巧',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(186,'2016-09-15 02:47:33','2','[整理] linux常用命令',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(187,'2016-09-15 05:10:22','11','emacs',1,'[{\"added\": {}}]',8,1),(188,'2016-09-15 05:13:33','19','[整理] emacs 常用功能整理',1,'[{\"added\": {}}]',7,1),(189,'2016-09-15 05:30:48','17','[原创]  django网站自动发布',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(190,'2016-09-15 05:33:29','17','[原创]  网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"title\", \"body\"]}}]',7,1),(191,'2016-09-15 08:48:43','3','[整理]  django学习资料',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(192,'2016-09-15 08:52:28','20','[整理] django常见问题',1,'[{\"added\": {}}]',7,1),(193,'2016-09-15 09:20:58','20','[整理] django常见问题',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(194,'2016-09-15 11:10:34','19','[整理] emacs 常用功能整理',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(195,'2016-09-15 11:12:59','19','[整理] emacs 常用功能整理',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(196,'2016-09-16 12:27:02','21','[整理]  linux脚本相关知识',1,'[{\"added\": {}}]',7,1),(197,'2016-09-16 12:27:18','21','[整理]  linux脚本相关知识',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(198,'2016-09-16 12:27:40','21','[整理]  linux脚本相关知识',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(199,'2016-09-16 12:37:20','21','[整理]  linux脚本相关知识',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(200,'2016-09-17 00:47:13','17','[原创]  网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(201,'2016-09-17 00:48:12','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"title\", \"body\"]}}]',7,1),(202,'2016-09-17 00:48:51','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(203,'2016-09-17 00:50:11','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(204,'2016-09-17 00:50:49','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(205,'2016-09-17 00:56:50','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(206,'2016-09-17 00:57:51','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(207,'2016-09-17 01:01:31','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(208,'2016-09-17 01:02:14','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(209,'2016-09-17 01:02:51','17','[原创]  django 网站自动发布(适用于所有项目)',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(210,'2016-09-17 01:26:20','7','[介绍]  aspera 下载软件',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',7,1),(211,'2016-09-17 12:21:07','22','[整理] python3 常用功能',1,'[{\"added\": {}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(2,'auth','group'),(4,'auth','permission'),(3,'auth','user'),(7,'blog','post'),(8,'blog','tag'),(5,'contenttypes','contenttype'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2016-09-11 09:28:19'),(2,'auth','0001_initial','2016-09-11 09:28:20'),(3,'admin','0001_initial','2016-09-11 09:28:20'),(4,'admin','0002_logentry_remove_auto_add','2016-09-11 09:28:20'),(5,'contenttypes','0002_remove_content_type_name','2016-09-11 09:28:20'),(6,'auth','0002_alter_permission_name_max_length','2016-09-11 09:28:20'),(7,'auth','0003_alter_user_email_max_length','2016-09-11 09:28:20'),(8,'auth','0004_alter_user_username_opts','2016-09-11 09:28:20'),(9,'auth','0005_alter_user_last_login_null','2016-09-11 09:28:20'),(10,'auth','0006_require_contenttypes_0002','2016-09-11 09:28:20'),(11,'auth','0007_alter_validators_add_error_messages','2016-09-11 09:28:20'),(12,'auth','0008_alter_user_username_max_length','2016-09-11 09:28:20'),(13,'blog','0001_initial','2016-09-11 09:28:20'),(14,'blog','0002_auto_20160828_1939','2016-09-11 09:28:20'),(15,'sessions','0001_initial','2016-09-11 09:28:20');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('do1i38dyykov3expbcow2ml7kzo8vr2t','NjNlN2QxNDkyYTI0ZDQzM2JmNzYxZTQ0MmE1Nzg1MjBiZWMzOTY1NTp7Il9hdXRoX3VzZXJfaGFzaCI6ImZlNTBkMmEyN2Q0ZmIxMTZkYTQ5OWU3NzE1NzEzNjljYzk5MGIzMTkiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2016-10-01 01:19:02'),('imozsiatpoddilalp86ahq878vv4or04','MTJlMTgxNjBjM2JmYWVhODI4NjQyNDdmZjRjZDY5ZGVlYmI5YmU5ZTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiZmU1MGQyYTI3ZDRmYjExNmRhNDk5ZTc3MTU3MTM2OWNjOTkwYjMxOSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2016-09-25 09:46:33');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-18 12:04:19
